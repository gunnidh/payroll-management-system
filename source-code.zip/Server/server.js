import express from 'express'
import cors from 'cors'
import cookieParser from 'cookie-parser'
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import mysql from 'mysql2'
import multer from 'multer'
import path from 'path'

const app = express();
app.use(cors(
    {
        origin: ["http://localhost:5173"],
        methods: ["POST", "GET", "PUT", "DELETE"],
        credentials: true
    }
));
app.use(cookieParser());
app.use(express.json());
app.use(express.static('public'));

const con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "db-company"
})

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/images')
    },
    filename: (req, file, cb) => {
        cb(null, file.fieldname + "_" + Date.now() + path.extname(file.originalname));
    }
})

const upload = multer({
    storage: storage
})

con.connect(function (err) {
    if (err) {
        console.log("Error in Connection", err);
    } else {
        console.log("Connected");
    }
})

app.get('/getEmployee', (req, res) => {

    const sql = "SELECT employee.id, employee.name, employee.email, employee.address, employee.image, compensation.salary, compensation.designation, compensation.houseRentAllowance, compensation.travelAllowance, compensation.dearnessAllowance, compensation.grossSalary, compensation.providentFund, compensation.pensionFund, compensation.bonusAmount, compensation.netSalary FROM employee INNER JOIN compensation ON employee.id = compensation.id";
    con.query(sql, (err, result) => {
        if (err)
            return res.json({ Error: "Get employee error in sql" });

        return res.json({ Status: "Success", Result: result })
    })
})

app.get('/getAdmins', (req, res) => {

    const sql = "SELECT * FROM user";
    con.query(sql, (err, result) => {
        if (err)
            return res.json({ Error: "Get employee error in sql" });

        return res.json({ Status: "Success", Result: result })
    })
})

app.get('/get/:id', (req, res) => {
    const id = req.params.id;
    const sql = "SELECT employee.id, employee.name, employee.email, employee.address, employee.image, compensation.salary, compensation.designation, compensation.houseRentAllowance, compensation.travelAllowance, compensation.dearnessAllowance, compensation.grossSalary, compensation.providentFund, compensation.pensionFund, compensation.bonusAmount, compensation.netSalary FROM employee INNER JOIN compensation ON employee.id = compensation.id WHERE compensation.id = ?";
    con.query(sql, [id], (err, result) => {
        if (err)
            return res.json({ Error: "Get employee error in sql" });
        return res.json({ Status: "Success", Result: result })
    })
})

app.get('/addAdmin/:id', (req, res) => {
    const id = req.params.id;
    const sql = "INSERT INTO user (id, email, password) select id, email, password from employee where id = ?";
    con.query(sql, [id], (err, result) => {
        if (err)
            return res.json({ Error: "Get employee error in sql" });
        return res.json({ Status: "Success", Result: result })
    })
})

app.get('/removeAdmin/:id', (req, res) => {
    const id = req.params.id;
    const sql = "DELETE FROM user WHERE id = ?";
    con.query(sql, [id], (err, result) => {
        if (err)
            return res.json({ Error: "Get employee error in sql" });
        return res.json({ Status: "Success", Result: result })
    })
})

const verifyUser = (req, res, next) => {
    const token = req.cookies.token;
    if (!token) {
        return res.json({ Error: "You are no Authenticated" });
    } else {
        jwt.verify(token, "jwt-secret-key", (err, decoded) => {
            if (err)
                return res.json({ Error: "Token wrong" });
            req.role = decoded.role;
            req.id = decoded.id;
            next();
        })
    }
}

app.get('/dashboard', verifyUser, (req, res) => {
    return res.json({ Status: "Success", role: req.role, id: req.id })
})

app.get('/logout', (req, res) => {
    res.clearCookie('token');
    return res.json({ Status: "Success" });
})

app.get('/adminCount', (req, res) => {
    const sql = "Select count(id) as admin from user";
    con.query(sql, (err, result) => {
        if (err)
            return res.json({ Error: "Error in runnig query" });
        return res.json(result);
    })
})

app.get('/employeeCount', (req, res) => {
    const sql = "Select count(id) as employee from employee";
    con.query(sql, (err, result) => {
        if (err)
            return res.json({ Error: "Error in runnig query" });
        return res.json(result);
    })
})

app.get('/salary', (req, res) => {
    const sql = "Select sum(salary) as sumOfSalary from employee";
    con.query(sql, (err, result) => {
        if (err) return res.json({ Error: "Error in runnig query" });
        return res.json(result);
    })
})

app.put('/update/:id', (req, res) => {
    const id = req.params.id;
    const sql = "UPDATE compensation set salary = ? , designation = ? WHERE id = ?";
    con.query(sql, [req.body.salary, req.body.designation, id], (err, result) => {
        if (err)
            return res.json({ Error: "update employee error in sql" });
        return res.json({ Status: "Success" })
    })
})

app.post('/login', (req, res) => {
    const sql = "SELECT * FROM user Where email = ? AND  password = ?";
    con.query(sql, [req.body.email, req.body.password], (err, result) => {

        if (err)
            return res.json({ Status: "Error", Error: "Error in runnig query" });

        if (result.length > 0) {
            const empId = result[0].id;
            const token = jwt.sign({ role: "admin", id: empId }, "jwt-secret-key", { expiresIn: '1d' });
            res.cookie('token', token);
            return res.json({ Status: "Success" })
        } else {
            return res.json({ Status: "Error", Error: "Wrong Email or Password" });
        }
    })
})

app.post('/employeeLogin', (req, res) => {
    const sql = "SELECT * FROM employee Where email = ?";
    con.query(sql, [req.body.email], (err, result) => {
        if (err) return res.json({ Status: "Error", Error: "Error in runnig query" });
        if (result.length > 0) {
            bcrypt.compare(req.body.password.toString(), result[0].password, (err, response) => {
                if (err) return res.json({ Error: "password error" });
                if (response) {
                    const token = jwt.sign({ role: "employee", id: result[0].id }, "jwt-secret-key", { expiresIn: '1d' });
                    res.cookie('token', token);
                    return res.json({ Status: "Success", id: result[0].id })
                } else {
                    return res.json({ Status: "Error", Error: "Wrong Email or Password" });
                }

            })

        } else {
            return res.json({ Status: "Error", Error: "Wrong Email or Password" });
        }
    })
})

app.post('/create', upload.single('image'), (req, res) => {
    console.log(req.file)
    const sql = "INSERT INTO employee (`name`,`email`,`password`, `address`,`image`) VALUES (?)";
    bcrypt.hash(req.body.password.toString(), 10, (err, hash) => {
        if (err) return res.json({ Error: "Error in hashing password" });
        const values = [
            req.body.name,
            req.body.email,
            hash,
            req.body.address,
            req.file.filename
        ]
        con.query(sql, [values], (err, results, fields) => {
            console.log("id: " + results.insertId);
            if (err)
                return res.json({ Error: "Inside create employee query" });

            const sql2 = "INSERT INTO compensation (`id`, `salary`, `designation`, `bonusAmount`) VALUES (?)";
            const compensationDetails = [
                results.insertId,
                req.body.salary,
                req.body.designation,
                req.body.bonus,
            ]
            console.log(compensationDetails)
            con.query(sql2, [compensationDetails], (err, results, fields) => {
                if (err)
                    return res.json({ Error: "Inside add employee compensation query" });
                return res.json({ Status: "Success" });
            })
        })
    })
})

app.delete('/delete/:id', (req, res) => {
    const id = req.params.id;
    const sql = "Delete FROM employee WHERE id = ?; ";
    con.query(sql, [id], (err, result) => {
        if (err)
            return res.json({ Error: "delete employee error in sql" });
        return res.json({ Status: "Success" })
    })
})

app.listen(8081, () => {
    console.log("Running");
})
